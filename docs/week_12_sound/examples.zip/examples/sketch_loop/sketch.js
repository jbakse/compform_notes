function preload() {
  mySound = loadSound('hack-comp.wav');
  mySound2 = loadSound('hack-comp.wav');
}

function setup() {
  mySound.loop(0, 1, 1, 0, 4);
  mySound2.loop(0, 1, 1, 0, 3.9);
}
